-- Bookings table for appointment reservations
CREATE TABLE bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  service TEXT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TEXT NOT NULL,
  notes TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  language TEXT DEFAULT 'en',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contact messages table
CREATE TABLE contact_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  message TEXT NOT NULL,
  language TEXT DEFAULT 'en',
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Testimonials table
CREATE TABLE testimonials (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review TEXT NOT NULL,
  service TEXT,
  is_approved BOOLEAN DEFAULT false,
  language TEXT DEFAULT 'en',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

-- RLS Policies for bookings (public can insert, only service role can read)
CREATE POLICY "public_insert_bookings" ON bookings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "service_read_bookings" ON bookings FOR SELECT
  TO service_role USING (true);

-- RLS Policies for contact_messages (public can insert, only service role can read)
CREATE POLICY "public_insert_contact_messages" ON contact_messages FOR INSERT
  WITH CHECK (true);

CREATE POLICY "service_read_contact_messages" ON contact_messages FOR SELECT
  TO service_role USING (true);

-- RLS Policies for testimonials (public can read approved, authenticated can insert)
CREATE POLICY "public_read_approved_testimonials" ON testimonials FOR SELECT
  USING (is_approved = true);

CREATE POLICY "public_insert_testimonials" ON testimonials FOR INSERT
  WITH CHECK (true);

-- Insert sample testimonials
INSERT INTO testimonials (name, rating, review, service, is_approved, language) VALUES
('Sara Al-Rashid', 5, 'Absolutely wonderful experience! The staff is incredibly professional and the salon is beautiful. My hair color came out perfect - exactly what I wanted. Will definitely be coming back!', 'Hair Coloring', true, 'en'),
('Fatima Mahmoud', 5, 'Highlooks is my go-to salon in Riyadh. Their bridal packages are exceptional. The team made me feel like a princess on my special day. Highly recommend!', 'Bridal Packages', true, 'en'),
('Noura Al-Hassan', 5, 'The facial treatments here are amazing. My skin has never looked better. The atmosphere is so relaxing and luxurious. Worth every riyal!', 'Facial Treatments', true, 'en'),
('Layla Ibrahim', 4, 'Great manicure and pedicure service. Very hygienic and professional. The nail technicians are skilled and pay attention to detail.', 'Manicure & Pedicure', true, 'en'),
('Amira Khalid', 5, 'Finally found a salon that understands Arabic beauty! The makeup artist did an incredible job for my engagement. Beautiful setting and excellent customer service.', 'Makeup Services', true, 'en'),
('Hana Al-Qasim', 5, 'My eyebrows have never looked better. The lash lift is amazing too! Very experienced staff who know exactly what they are doing.', 'Eyebrow & Eyelash Services', true, 'en');