import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About Us',
    'nav.services': 'Services',
    'nav.gallery': 'Gallery',
    'nav.testimonials': 'Testimonials',
    'nav.contact': 'Contact',
    'nav.book': 'Book Now',

    // Hero
    'hero.headline': 'Enhancing Your Beauty with Luxury & Care',
    'hero.subheadline': 'Professional beauty treatments in the heart of Riyadh.',
    'hero.bookAppointment': 'Book Appointment',
    'hero.callNow': 'Call Now',

    // About
    'about.title': 'About Us',
    'about.subtitle': 'Where Beauty Meets Excellence',
    'about.description': 'Welcome to Highlooks Beauty Salon, your premier destination for luxury beauty services in Riyadh. Founded with a passion for enhancing natural beauty, we combine traditional techniques with modern innovations to deliver exceptional results.',
    'about.mission': 'Our Mission',
    'about.missionText': 'To provide world-class beauty services that exceed expectations, using premium products and cutting-edge techniques in a luxurious, relaxing environment.',
    'about.professional': 'Professional Excellence',
    'about.professionalText': 'Our team of certified beauty specialists brings years of experience and continuous training in the latest beauty trends.',
    'about.hygiene': 'Premium Hygiene',
    'about.hygieneText': 'We maintain the highest standards of cleanliness and sanitation, using sterilized equipment for every treatment.',
    'about.satisfaction': 'Customer Satisfaction',
    'about.satisfactionText': 'Your happiness is our priority. We listen, understand, and deliver personalized services tailored to your unique needs.',
    'about.location': 'Prime Location',
    'about.locationText': 'Conveniently located in Al Olaya, Riyadh, with easy access and ample parking for our valued clients.',

    // Services
    'services.title': 'Our Services',
    'services.subtitle': 'Premium beauty treatments tailored for you',
    'services.bookNow': 'Book Now',

    // Gallery
    'gallery.title': 'Our Gallery',
    'gallery.subtitle': 'Discover our transformations and salon atmosphere',

    // Testimonials
    'testimonials.title': 'What Our Clients Say',
    'testimonials.subtitle': 'Real experiences from our valued guests',

    // Contact
    'contact.title': 'Get In Touch',
    'contact.subtitle': 'We would love to hear from you',
    'contact.name': 'Full Name',
    'contact.phone': 'Phone Number',
    'contact.email': 'Email Address',
    'contact.message': 'Your Message',
    'contact.sendMessage': 'Send Message',
    'contact.sending': 'Sending...',
    'contact.success': 'Message sent successfully!',
    'contact.findUs': 'Find Us',
    'contact.visitUs': 'Visit Our Salon',
    'contact.callUs': 'Call Us',
    'contact.emailUs': 'Email Us',

    // Booking
    'booking.title': 'Book Your Appointment',
    'booking.subtitle': 'Schedule your beauty experience',
    'booking.selectService': 'Select Service',
    'booking.selectDate': 'Select Date',
    'booking.selectTime': 'Select Time',
    'booking.yourDetails': 'Your Details',
    'booking.notes': 'Additional Notes (Optional)',
    'booking.confirmBooking': 'Confirm Booking',
    'booking.confirming': 'Confirming...',
    'booking.success': 'Booking confirmed! We will contact you shortly.',
    'booking.required': 'Required',

    // Footer
    'footer.rights': 'All Rights Reserved',
    'footer.followUs': 'Follow Us',

    // Common
    'common.learnMore': 'Learn More',
    'common.fromPrice': 'Starting from',
    'common.sar': 'SAR',
  },
  ar: {
    // Navigation
    'nav.home': 'الرئيسية',
    'nav.about': 'من نحن',
    'nav.services': 'خدماتنا',
    'nav.gallery': 'المعرض',
    'nav.testimonials': 'آراء العملاء',
    'nav.contact': 'اتصل بنا',
    'nav.book': 'احجز الآن',

    // Hero
    'hero.headline': 'نعزز جمالك بالفخامة والعناية',
    'hero.subheadline': 'خدمات تجميل احترافية في قلب الرياض',
    'hero.bookAppointment': 'احجز موعد',
    'hero.callNow': 'اتصل الآن',

    // About
    'about.title': 'من نحن',
    'about.subtitle': 'حيث يلتقي الجمال بالتميز',
    'about.description': 'مرحباً بكم في صالون هاي لوك beauté للتجميل، وجهتكم المميزة لخدمات الجمال الفاخرة في الرياض. أسسنا بمزيج من الشغف لتعزيز الجمال الطبيعي، نجمع بين التقنيات التقليدية والابتكارات الحديثة.',
    'about.mission': 'مهمتنا',
    'about.missionText': 'تقديم خدمات تجميل عالمية المستوى تتجاوز التوقعات، باستخدام منتجات فاخرة وتقنيات متطورة في بيئة فاخرة ومريحة.',
    'about.professional': 'احترافية عالية',
    'about.professionalText': 'يجلب فريقنا من المتخصصين المعتمدين سنوات من الخبرة والتدريب المستمر على أحدث صيحات الجمال.',
    'about.hygiene': 'نظافة ممتازة',
    'about.hygieneText': 'نحافظ على أعلى معايير النظافة والتعقيم، ونستخدم معدات معقمة لكل علاج.',
    'about.satisfaction': 'رضا العملاء',
    'about.satisfactionText': 'سعادتكم أولويتنا. نستمع ونفهم ونقدم خدمات مخصصة لاحتياجاتكم الفريدة.',
    'about.location': 'موقع متميز',
    'about.locationText': 'موقعنا في العليا بالرياض يسهل الوصول إليه مع مواقف سيارات كافية لعملائنا الكرام.',

    // Services
    'services.title': 'خدماتنا',
    'services.subtitle': 'خدمات تجميل فاخرة مصممة خصيصاً لكم',
    'services.bookNow': 'احجز الآن',

    // Gallery
    'gallery.title': 'معرض أعمالنا',
    'gallery.subtitle': 'اكتشفوا تحولاتنا وأجواء الصالون',

    // Testimonials
    'testimonials.title': 'ماذا يقول عملاؤنا',
    'testimonials.subtitle': 'تجارب حقيقية من ضيوفنا الكرام',

    // Contact
    'contact.title': 'تواصل معنا',
    'contact.subtitle': 'يسعدنا سماع رأيكم',
    'contact.name': 'الاسم الكامل',
    'contact.phone': 'رقم الهاتف',
    'contact.email': 'البريد الإلكتروني',
    'contact.message': 'رسالتكم',
    'contact.sendMessage': 'إرسال الرسالة',
    'contact.sending': 'جاري الإرسال...',
    'contact.success': 'تم إرسال الرسالة بنجاح!',
    'contact.findUs': 'ابحث عنا',
    'contact.visitUs': 'زر صالوننا',
    'contact.callUs': 'اتصل بنا',
    'contact.emailUs': 'راسلنا',

    // Booking
    'booking.title': 'احجز موعدك',
    'booking.subtitle': 'حدد موعد تجربتكم الجمالية',
    'booking.selectService': 'اختر الخدمة',
    'booking.selectDate': 'اختر التاريخ',
    'booking.selectTime': 'اختر الوقت',
    'booking.yourDetails': 'بياناتكم',
    'booking.notes': 'ملاحظات إضافية (اختياري)',
    'booking.confirmBooking': 'تأكيد الحجز',
    'booking.confirming': 'جاري التأكيد...',
    'booking.success': 'تم تأكيد الحجز! سنتواصل معكم قريباً.',
    'booking.required': 'مطلوب',

    // Footer
    'footer.rights': 'جميع الحقوق محفوظة',
    'footer.followUs': 'تابعونا',

    // Common
    'common.learnMore': 'اعرف المزيد',
    'common.fromPrice': 'تبدأ من',
    'common.sar': 'ريال',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL: language === 'ar' }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
