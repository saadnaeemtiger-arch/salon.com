import { SVGProps } from 'react';

export default function TiktokIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M16 7a4 4 0 1 1 0 8" />
      <path d="M8 7h6" />
      <path d="M8 11v4a4 4 0 0 0 8 0v-1" />
      <path d="M12 19.5v-8.5" />
      <path d="M6.5 14a8.5 8.5 0 0 0 15-4.5" />
    </svg>
  );
}
