import { SVGProps } from 'react';

export default function SnapchatIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 3c2.755 0 5.5.25 7 2.5 1.5 2.25 1 5 0 7.5-.75 2-2.25 3.5-4 4 .5.5 1 1 1 2s-.75 1.5-1.5 2c-.25.25-.5.5-.5 1s.25 1.5.75 2.25"/>
      <path d="M12 3c-2.755 0-5.5.25-7 2.5-1.5 2.25-1 5 0 7.5.75 2 2.25 3.5 4 4-.5.5-1 1-1 2s.75 1.5 1.5 2c.25.25.5.5.5 1s-.25 1.5-.75 2.25"/>
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
