import { useLanguage } from '../contexts/LanguageContext';
import { Scissors, Palette, Sparkles, Brush, HandMetalIcon, Flower, Eye, Heart, ArrowRight } from 'lucide-react';

interface Service {
  id: string;
  icon: typeof Scissors;
  titleKey: string;
  titleAr: string;
  descriptionKey: string;
  descriptionAr: string;
  benefitsKey: string;
  benefitsAr: string;
  price: number;
  image: string;
}

const services: Service[] = [
  {
    id: 'hair-styling',
    icon: Scissors,
    titleKey: 'Hair Styling',
    titleAr: 'تصفيف الشعر',
    descriptionKey: 'Expert cuts, blowouts, and styling for every occasion, from everyday looks to special events.',
    descriptionAr: 'قصات تصفيف وتمليس احترافية لكل مناسبة، من الإطلالات اليومية إلى المناسبات الخاصة.',
    benefitsKey: 'Personalized consultation, premium products, expert stylists',
    benefitsAr: 'استشارة مخصصة، منتجات فاخرة، خبراء تصفيف',
    price: 150,
    image: 'https://images.pexels.com/photos/1567718/pexels-photo-1567718.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'hair-coloring',
    icon: Palette,
    titleKey: 'Hair Coloring',
    titleAr: 'صبغ الشعر',
    descriptionKey: 'From natural tones to bold fashion colors, our expert colorists create your perfect shade.',
    descriptionAr: 'من الدرجات الطبيعية إلى الألوان الجريئة، خبراء الألوان لدينا يصنعون ظلك المثالي.',
    benefitsKey: 'Premium brands, color correction, balayage & ombre',
    benefitsAr: 'علامات تجارية فاخرة، تصحيح الألوان، بالاياج وأومبري',
    price: 300,
    image: 'https://images.pexels.com/photos/3997981/pexels-photo-3997982.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'hair-treatments',
    icon: Sparkles,
    titleKey: 'Hair Treatments',
    titleAr: 'علاجات الشعر',
    descriptionKey: 'Keratin, botox, deep conditioning & repair treatments to restore hair health and shine.',
    descriptionAr: 'علاجات الكيراتين والبوتوكس والتغذية العميقة لإعادة صحة ولمعان الشعر.',
    benefitsKey: 'Repair damage, add shine, long-lasting results',
    benefitsAr: 'إصلاح التلف، إضافة لمعان، نتائج طويلة الأمد',
    price: 500,
    image: 'https://images.pexels.com/photos/4915908/pexels-photo-4915908.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'makeup',
    icon: Brush,
    titleKey: 'Makeup Services',
    titleAr: 'خدمات المكياج',
    descriptionKey: 'Professional makeup for all occasions - bridal, party, photoshoot, or everyday glamour.',
    descriptionAr: 'مكياج احترافي لجميع المناسبات - زفاف، حفلات، تصوير، أو سحر يومي.',
    benefitsKey: 'HD makeup, airbrush technique, premium products',
    benefitsAr: 'مكياج HD، تقنية الأيربراش، منتجات فاخرة',
    price: 250,
    image: 'https://images.pexels.com/photos/2898406/pexels-photo-2898406.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'nails',
    icon: HandMetalIcon,
    titleKey: 'Manicure & Pedicure',
    titleAr: 'مانيكير وباديكير',
    descriptionKey: 'Luxury nail care with gel polish, nail art, and spa treatments for hands and feet.',
    descriptionAr: 'العناية بالأظافر الفاخرة مع جل بولش، نرح الأظافر، وعلاجات سبا لليدين والقدمين.',
    benefitsKey: 'Sanitized tools, luxury products, nail art options',
    benefitsAr: 'أدوات معقمة، منتجات فاخرة، خيارات فن الأظافر',
    price: 120,
    image: 'https://images.pexels.com/photos/3997386/pexels-photo-3997386.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'facials',
    icon: Flower,
    titleKey: 'Facial Treatments',
    titleAr: 'علاجات الوجه',
    descriptionKey: 'Deep cleansing, anti-aging, hydrating facials customized for your skin type.',
    descriptionAr: 'تنظيف عميق، مضاد للشيخوخة، ترطيب الوجه مخصص لنوع بشرتك.',
    benefitsKey: 'Skin analysis, clinical products, visible results',
    benefitsAr: 'تحليل البشرة، منتجات سريرية، نتائج مرئية',
    price: 200,
    image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'lashes',
    icon: Eye,
    titleKey: 'Eyebrow & Eyelash',
    titleAr: 'الحواجب والرموش',
    descriptionKey: 'Shaping, tinting, lash lifts, and extensions for perfectly framed eyes.',
    descriptionAr: 'تتشكيل، صبغة، رفع الرموش، وتمديدات لإطار مثالي للعيون.',
    benefitsKey: 'Precision shaping, premium materials, natural look',
    benefitsAr: 'تشكيل دقيق، مواد فاخرة، مظهر طبيعي',
    price: 100,
    image: 'https://images.pexels.com/photos/4907759/pexels-photo-4907759.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 'bridal',
    icon: Heart,
    titleKey: 'Bridal Packages',
    titleAr: 'باقات العروس',
    descriptionKey: 'Complete bridal beauty packages including hair, makeup, and spa treatments for your special day.',
    descriptionAr: 'باقات تجميل العروس الكاملة تشمل الشعر والمكياج وعلاجات السبا ليومك الخاص.',
    benefitsKey: 'Consultation, trial session, day-of service',
    benefitsAr: 'استشارة، جلسة تجربة، خدمة يوم الزفاف',
    price: 1500,
    image: 'https://images.pexels.com/photos/1691519/pexels-photo-1691519.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

export default function Services() {
  const { t, language } = useLanguage();

  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold-500 font-medium tracking-wider uppercase text-sm mb-4 block">
            {t('services.title')}
          </span>
          <h2 className="section-title mb-4">{t('services.title')}</h2>
          <p className="section-subtitle">{t('services.subtitle')}</p>
          <div className="gold-divider mt-6" />
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <div
              key={service.id}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg card-hover"
            >
              {/* Service Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={language === 'ar' ? service.titleAr : service.titleKey}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                  <span className="text-gold-400 font-bold text-lg">
                    {t('common.fromPrice')} {service.price} {t('common.sar')}
                  </span>
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                    <service.icon className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>

              {/* Service Content */}
              <div className="p-6">
                <h3 className="font-serif text-xl font-semibold text-gray-900 mb-2">
                  {language === 'ar' ? service.titleAr : service.titleKey}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {language === 'ar' ? service.descriptionAr : service.descriptionKey}
                </p>

                {/* Benefits */}
                <div className="text-xs text-gold-600 font-medium mb-4">
                  {language === 'ar' ? service.benefitsAr : service.benefitsKey}
                </div>

                {/* Book Button */}
                <a
                  href="#booking"
                  className="flex items-center justify-center gap-2 w-full py-2.5 border-2 border-gold-500 text-gold-600 rounded-lg hover:bg-gold-500 hover:text-black transition-all font-medium text-sm group"
                >
                  {t('services.bookNow')}
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform rtl:rotate-180" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
