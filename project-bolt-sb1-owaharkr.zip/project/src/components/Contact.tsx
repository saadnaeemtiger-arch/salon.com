import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function Contact() {
  const { t, isRTL, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const { error } = await supabase.from('contact_messages').insert({
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        message: formData.message,
        language,
      });

      if (error) throw error;
      setSuccess(true);
      setFormData({ name: '', phone: '', email: '', message: '' });
    } catch (err) {
      console.error('Error submitting form:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: t('contact.visitUs'),
      value: 'Askan Building 17, Al Olaya, Riyadh 12611 Saudi Arabia',
      valueAr: 'مبنى عسكان 17، العليا، الرياض 12611 المملكة العربية السعودية',
    },
    {
      icon: Phone,
      title: t('contact.callUs'),
      value: '+966 59 750 1646',
      link: 'tel:+966597501646',
    },
    {
      icon: Mail,
      title: t('contact.emailUs'),
      value: 'info@highlooks.com',
      link: 'mailto:info@highlooks.com',
    },
    {
      icon: Clock,
      title: language === 'ar' ? 'ساعات العمل' : 'Working Hours',
      value: 'Sat - Thu: 9AM - 9PM | Fri: 2PM - 9PM',
      valueAr: 'السبت - الخميس: 9ص - 9م | الجمعة: 2م - 9م',
    },
  ];

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-blush-50 skew-x-12 translate-x-1/4" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold-500 font-medium tracking-wider uppercase text-sm mb-4 block">
            {t('contact.title')}
          </span>
          <h2 className="section-title mb-4">{t('contact.title')}</h2>
          <p className="section-subtitle">{t('contact.subtitle')}</p>
          <div className="gold-divider mt-6" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Contact Form */}
          <div className={`bg-gray-50 rounded-3xl p-8 md:p-10 ${isRTL ? 'lg:order-2' : ''}`}>
            <h3 className="font-serif text-2xl font-semibold text-gray-900 mb-6">
              {language === 'ar' ? 'أرسل رسالة' : 'Send a Message'}
            </h3>

            {success ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                <p className="text-xl font-semibold text-gray-900 mb-2">
                  {t('contact.success')}
                </p>
                <button
                  onClick={() => setSuccess(false)}
                  className="text-gold-600 hover:text-gold-700 font-medium mt-4"
                >
                  {language === 'ar' ? 'إرسال رسالة أخرى' : 'Send another message'}
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('contact.name')} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 transition-all bg-white"
                    placeholder={language === 'ar' ? 'الاسم الكامل' : 'Your full name'}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('contact.phone')} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 transition-all bg-white"
                    placeholder="+966 5X XXX XXXX"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('contact.email')}
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 transition-all bg-white"
                    placeholder="email@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('contact.message')} *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 transition-all bg-white resize-none"
                    placeholder={language === 'ar' ? 'اكتب رسالتك هنا...' : 'Type your message here...'}
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full btn-gold flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                  {submitting ? t('contact.sending') : t('contact.sendMessage')}
                </button>
              </form>
            )}
          </div>

          {/* Contact Info & Map */}
          <div className={`${isRTL ? 'lg:order-1' : ''}`}>
            {/* Contact Cards */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {contactInfo.map((info, index) => (
                <div
                  key={index}
                  className="bg-gray-50 rounded-xl p-6 hover:bg-gold-50 hover:shadow-lg transition-all group"
                >
                  <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-gold-500 transition-colors">
                    <info.icon className="w-6 h-6 text-gold-600 group-hover:text-black transition-colors" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">{info.title}</h4>
                  {info.link ? (
                    <a
                      href={info.link}
                      className="text-gold-600 hover:text-gold-700 transition-colors"
                    >
                      {info.value}
                    </a>
                  ) : (
                    <p className="text-gray-600 text-sm">
                      {language === 'ar' && info.valueAr ? info.valueAr : info.value}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Google Map */}
            <div className="rounded-2xl overflow-hidden shadow-lg h-[300px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3625.643647473849!2d46.6753!3d24.7136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDQyJzQ5LjAiTiA0NsKwNDAnMzEuMSJF!5e0!3m2!1sen!2ssa!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Highlooks Beauty Salon Location"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
