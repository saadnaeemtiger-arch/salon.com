import { useLanguage } from '../contexts/LanguageContext';
import { Sparkles, MapPin, Phone, Mail, Instagram } from 'lucide-react';
import TiktokIcon from './icons/TiktokIcon';
import SnapchatIcon from './icons/SnapchatIcon';

export default function Footer() {
  const { t, language } = useLanguage();

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 border-t border-gold-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-gold-500 p-2 rounded-lg">
                <Sparkles className="w-6 h-6 text-black" />
              </div>
              <span className="font-serif text-xl font-bold text-white">
                Highlooks
              </span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed mb-6">
              {language === 'ar'
                ? 'صالون تجميل فاخر في قلب الرياض، نقدم خدمات تجميل احترافية بأيدي خبراء متخصصين'
                : 'Luxury beauty salon in the heart of Riyadh, offering professional beauty services by expert specialists'}
            </p>
            {/* Social Media */}
            <div className="flex gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-white/70 hover:bg-gold-500 hover:text-black transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-white/70 hover:bg-gold-500 hover:text-black transition-all"
              >
                <TiktokIcon className="w-5 h-5" />
              </a>
              <a
                href="https://snapchat.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-white/70 hover:bg-gold-500 hover:text-black transition-all"
              >
                <SnapchatIcon className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-6">
              {language === 'ar' ? 'روابط سريعة' : 'Quick Links'}
            </h4>
            <ul className="space-y-3">
              {['#home', '#about', '#services', '#gallery', '#testimonials', '#contact'].map((link, i) => {
                const labels = language === 'ar'
                  ? ['الرئيسية', 'من نحن', 'خدماتنا', 'المعرض', 'آراء العملاء', 'اتصل بنا']
                  : ['Home', 'About', 'Services', 'Gallery', 'Testimonials', 'Contact'];
                return (
                  <li key={link}>
                    <a
                      href={link}
                      className="text-white/60 hover:text-gold-400 transition-colors text-sm"
                    >
                      {labels[i]}
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-6">
              {language === 'ar' ? 'خدماتنا' : 'Our Services'}
            </h4>
            <ul className="space-y-3">
              {(language === 'ar'
                ? ['تصفيف الشعر', 'صبغ الشعر', 'المكياج', 'العناية بالأظافر', 'علاجات الوجه', 'باقة العروس']
                : ['Hair Styling', 'Hair Coloring', 'Makeup', 'Nails', 'Facials', 'Bridal Packages']
              ).map((service, i) => (
                <li key={i}>
                  <a
                    href="#services"
                    className="text-white/60 hover:text-gold-400 transition-colors text-sm"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-6">
              {t('contact.title')}
            </h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-white/60 hover:text-gold-400 transition-colors text-sm group"
                >
                  <MapPin className="w-5 h-5 text-gold-500 flex-shrink-0 mt-0.5" />
                  <span>
                    {language === 'ar'
                      ? 'مبنى عسكان 17، العليا، الرياض 12611'
                      : 'Askan Building 17, Al Olaya, Riyadh 12611'}
                  </span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+966597501646"
                  className="flex items-center gap-3 text-white/60 hover:text-gold-400 transition-colors text-sm"
                >
                  <Phone className="w-5 h-5 text-gold-500 flex-shrink-0" />
                  <span>+966 59 750 1646</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@highlooks.com"
                  className="flex items-center gap-3 text-white/60 hover:text-gold-400 transition-colors text-sm"
                >
                  <Mail className="w-5 h-5 text-gold-500 flex-shrink-0" />
                  <span>info@highlooks.com</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/50 text-sm">
            {currentYear} Highlooks Beauty Salon. {t('footer.rights')}
          </p>
          <div className="flex items-center gap-6 text-white/50 text-sm">
            {language === 'ar' ? (
              <>
                <a href="#" className="hover:text-gold-400 transition-colors">سياسة الخصوصية</a>
                <a href="#" className="hover:text-gold-400 transition-colors">الشروط والأحكام</a>
              </>
            ) : (
              <>
                <a href="#" className="hover:text-gold-400 transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-gold-400 transition-colors">Terms of Service</a>
              </>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
