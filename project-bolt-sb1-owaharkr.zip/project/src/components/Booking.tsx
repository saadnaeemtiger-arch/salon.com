import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Calendar, Clock, User, Phone, Mail, FileText, CheckCircle, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';

const servicesData = [
  { id: 'hair-styling', nameEn: 'Hair Styling', nameAr: 'تصفيف الشعر', price: 150 },
  { id: 'hair-coloring', nameEn: 'Hair Coloring', nameAr: 'صبغ الشعر', price: 300 },
  { id: 'hair-treatment', nameEn: 'Hair Treatments', nameAr: 'علاجات الشعر', price: 500 },
  { id: 'makeup', nameEn: 'Makeup Services', nameAr: 'خدمات المكياج', price: 250 },
  { id: 'manicure-pedicure', nameEn: 'Manicure & Pedicure', nameAr: 'مانيكير وباديكير', price: 120 },
  { id: 'facial', nameEn: 'Facial Treatments', nameAr: 'علاجات الوجه', price: 200 },
  { id: 'brows-lashes', nameEn: 'Eyebrow & Eyelash', nameAr: 'الحواجب والرموش', price: 100 },
  { id: 'bridal', nameEn: 'Bridal Package', nameAr: 'باقة العروس', price: 1500 },
];

const timeSlots = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
  '15:00', '15:30', '16:00', '16:30', '17:00', '17:30',
  '18:00', '18:30', '19:00', '19:30', '20:00', '20:30',
];

export default function Booking() {
  const { t, language } = useLanguage();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    service: '',
    date: '',
    time: '',
    name: '',
    phone: '',
    email: '',
    notes: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const selectedService = servicesData.find(s => s.id === formData.service);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const { error } = await supabase.from('bookings').insert({
        service: formData.service,
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        appointment_date: formData.date,
        appointment_time: formData.time,
        notes: formData.notes,
        language,
      });

      if (error) throw error;
      setSuccess(true);
    } catch (err) {
      console.error('Error booking:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const nextStep = () => setStep((prev) => Math.min(prev + 1, 3));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 1));

  if (success) {
    return (
      <section id="booking" className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-gray-800/50 rounded-3xl p-12 border border-gold-500/20">
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
            <h2 className="text-3xl font-serif font-bold text-white mb-4">
              {t('booking.success')}
            </h2>
            <p className="text-white/70 mb-8">
              {language === 'ar'
                ? 'سنتواصل معك قريباً لتأكيد موعدك'
                : 'We will contact you soon to confirm your appointment'}
            </p>
            <button
              onClick={() => {
                setSuccess(false);
                setStep(1);
                setFormData({ service: '', date: '', time: '', name: '', phone: '', email: '', notes: '' });
              }}
              className="btn-gold"
            >
              {language === 'ar' ? 'حجز جديد' : 'New Booking'}
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="booking" className="py-24 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-gold-400 font-medium tracking-wider uppercase text-sm mb-4 block">
            {t('booking.title')}
          </span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
            {t('booking.title')}
          </h2>
          <p className="text-white/70 max-w-2xl mx-auto">{t('booking.subtitle')}</p>
          <div className="w-24 h-1 bg-gold-500 mx-auto mt-6 rounded-full" />
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-12">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm transition-all ${
                  step >= s
                    ? 'bg-gold-500 text-black'
                    : 'bg-gray-700 text-white/50'
                }`}
              >
                {step > s ? <CheckCircle className="w-5 h-5" /> : s}
              </div>
              {s < 3 && (
                <div
                  className={`w-16 h-1 mx-2 rounded-full transition-all ${
                    step > s ? 'bg-gold-500' : 'bg-gray-700'
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {/* Booking Card */}
        <div className="bg-gray-800/50 backdrop-blur-md rounded-3xl border border-gold-500/20 overflow-hidden">
          {/* Step 1: Select Service */}
          {step === 1 && (
            <div className="p-8">
              <div className="flex items-center gap-2 mb-6 text-gold-400">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-semibold">{t('booking.selectService')}</h3>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {servicesData.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => setFormData({ ...formData, service: service.id })}
                    className={`p-4 rounded-xl border-2 transition-all text-center ${
                      formData.service === service.id
                        ? 'border-gold-500 bg-gold-500/20'
                        : 'border-gray-600 hover:border-gold-500/50'
                    }`}
                  >
                    <span className="block text-white font-medium text-sm mb-1">
                      {language === 'ar' ? service.nameAr : service.nameEn}
                    </span>
                    <span className="text-gold-400 text-xs">From {service.price} SAR</span>
                  </button>
                ))}
              </div>

              <div className="mt-8 flex justify-end">
                <button
                  onClick={nextStep}
                  disabled={!formData.service}
                  className="btn-gold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {language === 'ar' ? 'التالي' : 'Next'}
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Select Date & Time */}
          {step === 2 && (
            <div className="p-8">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Date Selection */}
                <div>
                  <div className="flex items-center gap-2 mb-4 text-gold-400">
                    <Calendar className="w-5 h-5" />
                    <h3 className="font-semibold">{t('booking.selectDate')}</h3>
                  </div>
                  <input
                    type="date"
                    min={today}
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-gray-700 border border-gray-600 text-white focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 transition-all"
                  />
                </div>

                {/* Time Selection */}
                <div>
                  <div className="flex items-center gap-2 mb-4 text-gold-400">
                    <Clock className="w-5 h-5" />
                    <h3 className="font-semibold">{t('booking.selectTime')}</h3>
                  </div>
                  <div className="grid grid-cols-4 gap-2 max-h-[200px] overflow-y-auto pr-2">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setFormData({ ...formData, time })}
                        className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                          formData.time === time
                            ? 'bg-gold-500 text-black'
                            : 'bg-gray-700 text-white hover:bg-gray-600'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Selected Summary */}
              {selectedService && (
                <div className="mt-6 p-4 bg-gray-700/50 rounded-xl">
                  <p className="text-white/70 text-sm">
                    {language === 'ar' ? 'الخدمة المختارة:' : 'Selected Service:'}{' '}
                    <span className="text-gold-400">
                      {language === 'ar' ? selectedService.nameAr : selectedService.nameEn}
                    </span>
                  </p>
                </div>
              )}

              <div className="mt-8 flex justify-between">
                <button onClick={prevStep} className="btn-outline-gold">
                  {language === 'ar' ? 'السابق' : 'Back'}
                </button>
                <button
                  onClick={nextStep}
                  disabled={!formData.date || !formData.time}
                  className="btn-gold disabled:opacity-50"
                >
                  {language === 'ar' ? 'التالي' : 'Next'}
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Personal Details */}
          {step === 3 && (
            <div className="p-8">
              <div className="flex items-center gap-2 mb-6 text-gold-400">
                <User className="w-5 h-5" />
                <h3 className="font-semibold">{t('booking.yourDetails')}</h3>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white/70 text-sm mb-2">{t('contact.name')} *</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl bg-gray-700 border border-gray-600 text-white focus:border-gold-500"
                      placeholder={language === 'ar' ? 'الاسم الكامل' : 'Your full name'}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">{t('contact.phone')} *</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl bg-gray-700 border border-gray-600 text-white focus:border-gold-500"
                      placeholder="+966 5X XXX XXXX"
                    />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-white/70 text-sm mb-2">{t('contact.email')}</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl bg-gray-700 border border-gray-600 text-white focus:border-gold-500"
                      placeholder="email@example.com"
                    />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-white/70 text-sm mb-2">{t('booking.notes')}</label>
                  <div className="relative">
                    <FileText className="absolute left-4 top-4 w-5 h-5 text-gray-400" />
                    <textarea
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 rounded-xl bg-gray-700 border border-gray-600 text-white focus:border-gold-500 resize-none"
                      placeholder={language === 'ar' ? 'أي ملاحظات إضافية...' : 'Any additional notes...'}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-8 flex justify-between">
                <button onClick={prevStep} className="btn-outline-gold">
                  {language === 'ar' ? 'السابق' : 'Back'}
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!formData.name || !formData.phone || submitting}
                  className="btn-gold flex items-center gap-2 disabled:opacity-50"
                >
                  {submitting ? t('booking.confirming') : t('booking.confirmBooking')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
