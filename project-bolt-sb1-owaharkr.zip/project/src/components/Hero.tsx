import { useLanguage } from '../contexts/LanguageContext';
import { Phone, Calendar } from 'lucide-react';

export default function Hero() {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Luxury Beauty Salon"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 border border-gold-500/20 rounded-full animate-pulse hidden lg:block" />
      <div className="absolute bottom-40 right-20 w-48 h-48 border border-gold-500/10 rounded-full hidden lg:block" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Small Tagline */}
        <div className="animate-fade-in mb-6">
          <span className="inline-block px-6 py-2 border border-gold-500 text-gold-400 text-sm tracking-[0.3em] uppercase rounded-full">
            Luxury Beauty Experience
          </span>
        </div>

        {/* Main Headline */}
        <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-slide-up">
          {t('hero.headline')}
        </h1>

        {/* Subheadline */}
        <p className="text-lg sm:text-xl text-white/80 mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.2s' }}>
          {t('hero.subheadline')}
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          <a
            href="#booking"
            className="btn-gold flex items-center gap-2 group"
          >
            <Calendar className="w-5 h-5 group-hover:rotate-12 transition-transform" />
            {t('hero.bookAppointment')}
          </a>
          <a
            href="tel:+966597501646"
            className="btn-white flex items-center gap-2 group"
          >
            <Phone className="w-5 h-5 group-hover:rotate-12 transition-transform" />
            {t('hero.callNow')}
          </a>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-float hidden md:block">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2">
            <div className="w-1.5 h-2.5 bg-gold-400 rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}
