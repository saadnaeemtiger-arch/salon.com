import { useLanguage } from '../contexts/LanguageContext';
import { Award, Shield, Heart, MapPin, Sparkles } from 'lucide-react';

export default function About() {
  const { t, isRTL } = useLanguage();

  const features = [
    {
      icon: Award,
      title: t('about.professional'),
      description: t('about.professionalText'),
    },
    {
      icon: Shield,
      title: t('about.hygiene'),
      description: t('about.hygieneText'),
    },
    {
      icon: Heart,
      title: t('about.satisfaction'),
      description: t('about.satisfactionText'),
    },
    {
      icon: MapPin,
      title: t('about.location'),
      description: t('about.locationText'),
    },
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent" />
      <div className="absolute -left-32 top-1/2 w-64 h-64 bg-blush-100 rounded-full blur-3xl opacity-50" />
      <div className="absolute -right-32 bottom-1/4 w-96 h-96 bg-gold-100 rounded-full blur-3xl opacity-30" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold-500 font-medium tracking-wider uppercase text-sm mb-4 block">
            {t('about.title')}
          </span>
          <h2 className="section-title mb-4">{t('about.subtitle')}</h2>
          <div className="gold-divider mt-6" />
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          {/* Image */}
          <div className={`relative ${isRTL ? 'lg:order-2' : ''}`}>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1522369/pexels-photo-1522369.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Highlooks Beauty Salon Interior"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-6 lg:right-6 bg-gold-500 text-black p-6 rounded-2xl shadow-xl">
              <div className="flex items-center gap-3">
                <Sparkles className="w-8 h-8" />
                <div>
                  <span className="block text-2xl font-bold">10+</span>
                  <span className="text-sm">Years Experience</span>
                </div>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className={`${isRTL ? 'lg:order-1' : ''}`}>
            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              {t('about.description')}
            </p>

            {/* Mission Statement */}
            <div className="bg-gray-50 rounded-xl p-6 mb-8 border-l-4 border-gold-500">
              <h3 className="font-serif text-xl font-semibold text-gray-900 mb-2">
                {t('about.mission')}
              </h3>
              <p className="text-gray-600">{t('about.missionText')}</p>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="text-center p-6 rounded-xl bg-gray-50 hover:bg-white hover:shadow-xl transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-gold-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-gold-500 transition-colors">
                <feature.icon className="w-7 h-7 text-gold-600 group-hover:text-black transition-colors" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
