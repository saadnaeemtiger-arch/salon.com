import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

const galleryImages = [
  {
    src: 'https://images.pexels.com/photos/3993294/pexels-photo-3993294.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Hair Coloring Transformation',
    titleAr: 'تحويل صبغ الشعر',
    category: 'before-after',
  },
  {
    src: 'https://images.pexels.com/photos/1522369/pexels-photo-1522369.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Salon Interior',
    titleAr: 'ديكور الصالون',
    category: 'interior',
  },
  {
    src: 'https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Bridal Makeup',
    titleAr: 'مكياج العروس',
    category: 'makeup',
  },
  {
    src: 'https://images.pexels.com/photos/4915908/pexels-photo-4915908.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Hair Treatment Results',
    titleAr: 'نتائج علاج الشعر',
    category: 'treatment',
  },
  {
    src: 'https://images.pexels.com/photos/2898406/pexels-photo-2898406.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Professional Makeup Session',
    titleAr: 'جلسة مكياج احترافية',
    category: 'makeup',
  },
  {
    src: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Facial Treatment',
    titleAr: 'علاج الوجه',
    category: 'facial',
  },
  {
    src: 'https://images.pexels.com/photos/3997386/pexels-photo-3997386.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Nail Art Design',
    titleAr: 'تصميم فن الأظافر',
    category: 'nails',
  },
  {
    src: 'https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Luxury Beauty Session',
    titleAr: 'جلسة تجميل فاخرة',
    category: 'featured',
  },
  {
    src: 'https://images.pexels.com/photos/3997981/pexels-photo-3997982.jpeg?auto=compress&cs=tinysrgb&w=800',
    title: 'Hair Styling',
    titleAr: 'تصفيف الشعر',
    category: 'hair',
  },
];

const categories = [
  { id: 'all', label: 'All', labelAr: 'الكل' },
  { id: 'hair', label: 'Hair', labelAr: 'الشعر' },
  { id: 'makeup', label: 'Makeup', labelAr: 'المكياج' },
  { id: 'nails', label: 'Nails', labelAr: 'الأظافر' },
  { id: 'treatment', label: 'Treatments', labelAr: 'العلاجات' },
];

export default function Gallery() {
  const { t, language } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const filteredImages = activeCategory === 'all'
    ? galleryImages
    : galleryImages.filter(img => img.category === activeCategory);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  const navigateImage = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    const newIndex = direction === 'prev'
      ? (selectedImage - 1 + filteredImages.length) % filteredImages.length
      : (selectedImage + 1) % filteredImages.length;
    setSelectedImage(newIndex);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedImage === null) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') navigateImage('prev');
      if (e.key === 'ArrowRight') navigateImage('next');
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage]);

  return (
    <section id="gallery" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-gold-400 font-medium tracking-wider uppercase text-sm mb-4 block">
            {t('gallery.title')}
          </span>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
            {t('gallery.title')}
          </h2>
          <p className="text-white/70 max-w-2xl mx-auto">{t('gallery.subtitle')}</p>
          <div className="gold-divider mt-6" />
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-6 py-2.5 rounded-full font-medium text-sm transition-all ${
                activeCategory === cat.id
                  ? 'bg-gold-500 text-black'
                  : 'border border-white/30 text-white/70 hover:border-gold-500 hover:text-gold-400'
              }`}
            >
              {language === 'ar' ? cat.labelAr : cat.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredImages.map((image, index) => (
            <div
              key={index}
              onClick={() => openLightbox(index)}
              className="relative cursor-pointer group overflow-hidden rounded-xl aspect-square"
            >
              <img
                src={image.src}
                alt={language === 'ar' ? image.titleAr : image.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <p className="text-white font-medium text-sm">
                  {language === 'ar' ? image.titleAr : image.title}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox */}
        {selectedImage !== null && (
          <div
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className="absolute top-6 right-6 text-white/70 hover:text-white transition-colors"
            >
              <X className="w-8 h-8" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); navigateImage('prev'); }}
              className="absolute left-4 md:left-8 text-white/70 hover:text-white transition-colors p-2"
            >
              <ChevronLeft className="w-8 h-8" />
            </button>

            <img
              src={filteredImages[selectedImage].src}
              alt={language === 'ar' ? filteredImages[selectedImage].titleAr : filteredImages[selectedImage].title}
              className="max-w-full max-h-[90vh] object-contain rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />

            <button
              onClick={(e) => { e.stopPropagation(); navigateImage('next'); }}
              className="absolute right-4 md:right-8 text-white/70 hover:text-white transition-colors p-2"
            >
              <ChevronRight className="w-8 h-8" />
            </button>

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center">
              <p className="text-white font-medium">
                {language === 'ar' ? filteredImages[selectedImage].titleAr : filteredImages[selectedImage].title}
              </p>
              <p className="text-white/50 text-sm mt-1">
                {selectedImage + 1} / {filteredImages.length}
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
